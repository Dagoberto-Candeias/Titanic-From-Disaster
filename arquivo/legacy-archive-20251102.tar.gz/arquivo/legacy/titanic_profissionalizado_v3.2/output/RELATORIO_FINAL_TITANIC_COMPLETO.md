Universidade Federal de Viçosa (UFV)
Departamento de Engenharia Elétrica – ELT579 – Aprendizado de Máquina
Projeto: Titanic – Machine Learning from Disaster
Autor: Dagoberto Candeias de Moraes
Ano: 2025


# RELATÓRIO FINAL — TITANIC (VERSÃO PROFISSIONALIZADA)

## Resumo
Este relatório apresenta o trabalho completo do projeto Titanic — Machine Learning from Disaster.
Objetivo: melhorar a acurácia e a interpretabilidade do modelo, gerando um artefato reprodutível e didático para uso acadêmico.

**Palavras-chave:** Titanic, classificação, Random Forest, engenharia de atributos, reproducibilidade, ELT579

## 1. Introdução
Contextualização e motivação: competição Kaggle e relevância pedagógica do conjunto Titanic.

## 2. Objetivo
Melhorar a acurácia (accuracy) e a interpretabilidade do modelo, mantendo reprodutibilidade e documentação adequada.

## 3. Metodologia
### 3.1 Setup e verificação de dependências
O projeto contém um mecanismo de verificação e instalação automática de dependências (função ensure_packages()).
O script principal detecta execução em Colab e adapta instruções de upload manual do arquivo `train.csv` para `data/raw/`.

### 3.2 Análise Exploratória de Dados (EDA)
Foram geradas automaticamente as figuras: distribuição de sobrevivência, sobrevivência por classe (Pclass),
por sexo (Sex), distribuição de idades e mapa de correlação. As figuras ficam em `output/graficos/`.

### 3.3 Engenharia de Atributos (Feature Engineering)
Foram extraídas e transformadas variáveis relevantes (ex.: Title extraído de Name, FamilySize, IsAlone, etc.).
As transformações são comentadas no script principal.

### 3.4 Pré-processamento e padronização
Tratamento de valores ausentes: Age (mediana), Embarked (moda 'S'), Fare (mediana quando necessário).
Codificações: Sex (male/female -> 0/1), One-Hot para Embarked quando aplicável.
Padronização opcional para algoritmos de distância (não aplicada à Random Forest por padrão).

### 3.5 Modelagem e validação cruzada
Modelo final: RandomForestClassifier como baseline robusta.
Validação: split treino/test (80/20) e validação cruzada estratificada quando aplicável.
Métricas calculadas: accuracy, precision, recall, F1-score e ROC AUC.

### 3.6 Geração do relatório automático
O script principal (`ELT579_118550_Titanic_Final_Profissionalizado.py`) gera automaticamente os gráficos,
salva métricas em `output/summary.json` e produz o arquivo Markdown `output/RELATORIO_FINAL_TITANIC_COMPLETO.md`.
Conversões para DOCX/PDF são realizadas por `scripts/gerar_relatorios.py` ou diretamente pelo script principal,
utilizando `python-docx` e `reportlab` como fallback quando `pandoc` não está disponível.

## 4. Resultados e Discussão
(As tabelas e figuras geradas automaticamente serão inseridas aqui quando o script for executado com o dataset `train.csv`.)

### 4.1 Comparação entre código original (Semana 1) e código final otimizado
**O que foi feito:** Implementações de correções, engenharia de atributos e pequenas otimizações de pipeline.
**Por que é necessário:** Melhor tratamento de dados ausentes, features mais informativas e pipeline reprodutível.
**Impacto:** Espera-se ganho em métricas e maior interpretabilidade (ver métricas em `output/summary.json`).

### 4.2 Métricas de desempenho
As métricas são salvas em `output/summary.json` e sumarizadas em tabela e texto no relatório.

## 5. Conclusões e Trabalhos Futuros
Síntese dos ganhos e recomendações: tuning com Optuna, explicabilidade com SHAP, ensembles e validação temporal se aplicável.

## 6. Apêndice
### Apêndice A – Diretrizes de Geração do Relatório
- **Objetivo:** Gerar um relatório técnico-acadêmico completo e um script Python totalmente comentado, com explicações didáticas e resultados comparativos entre o código original (Semana 1) e o código final otimizado.
- **Arquitetura do Projeto Final:** Script principal `ELT579_118550_Titanic_Final_Profissionalizado.py`, relatório em `output/RELATORIO_FINAL_TITANIC_COMPLETO.md` e versões .docx/.pdf, figuras em `output/graficos/` e `output/summary.json`.
- **Padrão Linguístico:** Português técnico (termos técnicos em inglês entre parênteses quando necessário). Gráficos em português, preservando nomes técnicos originais (ex.: Accuracy, F1-score).
- **Formato e Estrutura do Relatório:** Seguir estrutura científica: Resumo, Introdução, Objetivos, Metodologia, Resultados, Conclusões e Apêndices.
- **Gráficos e Visualizações:** Tema seaborn: whitegrid; incluir todas as figuras listadas nas diretrizes.
- **Automação do Script:** incluir ensure_packages(), detecção de main/run_pipeline, geração automática de .md e .docx, compatibilidade Colab/Spyder/VSCode.
- **Blocos explicativos padrão:** Fornecer para cada melhoria o formato: O que foi feito / Por que é necessário / Impacto.
- **Execução no Colab:** Instruções de upload e execução no apêndice B do relatório.
- **Decisões finais:** Idioma em Português; tema seaborn whitegrid; inclusão de feature importance; comparação Original vs Final; geração automática (.md e .docx); estilo acadêmico.

---
*Apêndice inserido automaticamente conforme solicitadoo.*
