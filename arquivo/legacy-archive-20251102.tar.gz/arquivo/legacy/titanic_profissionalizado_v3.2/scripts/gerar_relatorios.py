# scripts/gerar_relatorios.py
# Usa pandoc se disponível, caso contrário apenas informa ao usuário como gerar os arquivos.
import shutil
import subprocess
import sys
from pathlib import Path

md = Path("output/RELATORIO_FINAL_TITANIC_COMPLETO.md")
if not md.exists():
    print("Markdown não encontrado. Execute o pipeline primeiro.")
    sys.exit(1)
if shutil.which("pandoc"):
    subprocess.check_call(
        [
            "pandoc",
            str(md),
            "-o",
            "output/RELATORIO_FINAL_TITANIC_COMPLETO.pdf",
            "--pdf-engine=xelatex",
        ]
    )
    subprocess.check_call(
        ["pandoc", str(md), "-o", "output/RELATORIO_FINAL_TITANIC_COMPLETO.docx"]
    )
    print("Arquivos gerados com pandoc.")
else:
    print(
        "Pandoc não disponível. Use python-docx/reportlab no ambiente ou instale pandoc."
    )
