"""run_pipeline.py
Orquestrador do pipeline (PT/EN). Executar localmente após colocar `data/raw/train.csv`.
"""

import argparse
from src.preprocessing import load_and_preprocess
from src.features import build_features
from src.modeling import train_and_evaluate
from src.reporting import render_report


def main(data_path: str, output_dir: str, random_seed: int = 42):
    df = load_and_preprocess(data_path)
    X, y = build_features(df)
    model, metrics = train_and_evaluate(X, y, seed=random_seed)
    render_report(df, X, y, model, metrics, output_dir)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run Titanic professional pipeline (PT/EN)"
    )
    parser.add_argument(
        "--data",
        type=str,
        default="data/raw/train.csv",
        help="Caminho para o CSV de entrada / path to input CSV",
    )
    parser.add_argument(
        "--out",
        type=str,
        default="reports/",
        help="Diretório de saída / output directory",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    args = parser.parse_args()
    main(args.data, args.out, args.seed)
