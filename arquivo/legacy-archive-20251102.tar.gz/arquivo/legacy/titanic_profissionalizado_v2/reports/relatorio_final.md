# Relatório Final — Titanic (Versão Profissionalizada)

## 1. Resumo Executivo / Executive Summary

**PT:** Este projeto apresenta uma pipeline profissional para análise do conjunto Titanic, incluindo ETL, engenharia de features, treinamento de modelo e relatório com visualizações.

**EN:** This project provides a professional pipeline for the Titanic dataset including ETL, feature engineering, model training and report with visualizations.

## 2. Estrutura do repositório / Repository structure
- `run_pipeline.py` — Orquestrador do pipeline. (PT/EN)
- `src/` — Módulos de código.
- `analyses/` — Scripts e notebooks complementares.

## 3. Principais decisões técnicas / Technical choices
- Modelo base: RandomForest (boa baseline robusta / robust baseline)
- Métricas: Accuracy e ROC-AUC

## 4. Resultados / Results
- Inserir métricas geradas em `reports/metrics.md`
- Gráficos em `reports/figures/`

## 5. Conclusões e Próximos Passos / Conclusions & Next Steps
- Refinar features (ex.: combinar familysize, títulos menos comuns)
- Testar modelos avançados (XGBoost, LightGBM)
- Implementar validação por CV e tuning de hiperparâmetros

## 6. Como rodar (local / Colab)
- Local: veja README.md
- Colab: abra `notebooks/Run_Pipeline_Colab.ipynb` e siga as células (upload manual do CSV em `data/raw/train.csv`)

*Documento gerado automaticamente — v2*
