# Titanic — Versão Profissionalizada (v2)

Este repositório contém uma pipeline profissional bilíngue (PT/EN) para o dataset Titanic.
O dataset **deve** ser colocado manualmente em `data/raw/train.csv` (conforme solicitado).

Principais comandos:
- Local: criar ambiente, instalar dependências e rodar `python run_pipeline.py --data data/raw/train.csv --out reports/`
- Colab: abrir `notebooks/Run_Pipeline_Colab.ipynb` e seguir as células de setup (há instruções para upload manual do CSV).

Entregáveis: scripts em `src/`, notebooks em `notebooks/`, relatório em `reports/relatorio_final.md` (+ PDF + DOCX gerados), figuras em `reports/figures/`.
