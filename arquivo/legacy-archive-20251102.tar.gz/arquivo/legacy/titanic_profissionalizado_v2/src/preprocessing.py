"""Carregamento e pré-processamento básico (PT/EN)"""

import pandas as pd
from .utils import load_csv


def load_and_preprocess(path: str) -> pd.DataFrame:
    df = load_csv(path)
    # manter coluna de rastreabilidade
    df["_original_index"] = df.index
    if "Age" in df.columns:
        df["Age"] = df["Age"].fillna(df["Age"].median())
    if "Embarked" in df.columns:
        df["Embarked"] = df["Embarked"].fillna("S")
    if "Name" in df.columns:
        df["Title"] = df["Name"].str.extract(r",\s*([^\.]+)\.")
        df["Title"] = df["Title"].replace(["Mlle", "Ms"], "Miss").replace("Mme", "Mrs")
    return df
