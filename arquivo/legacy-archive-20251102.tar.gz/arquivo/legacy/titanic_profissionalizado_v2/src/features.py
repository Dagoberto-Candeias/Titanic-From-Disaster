"""Feature engineering: transformação de colunas e codificação (PT/EN)"""

import pandas as pd


def build_features(df: pd.DataFrame):
    features = []
    for c in ["Pclass", "Sex", "Age", "Fare"]:
        if c in df.columns:
            features.append(c)
    X = df[features].copy()
    if "Sex" in X.columns:
        X["Sex"] = X["Sex"].map({"male": 0, "female": 1})
    X = X.fillna(X.median(numeric_only=True))
    y = df["Survived"] if "Survived" in df.columns else None
    return X, y
