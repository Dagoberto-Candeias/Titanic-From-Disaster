"""Relatórios: gerar figuras e um arquivo markdown resumo (PT/EN)"""

import os
import matplotlib.pyplot as plt
import seaborn as sns


def render_report(df, X, y, model, metrics, out_dir="reports/"):
    os.makedirs(out_dir, exist_ok=True)
    figs_dir = os.path.join(out_dir, "figures")
    os.makedirs(figs_dir, exist_ok=True)
    if "Age" in df.columns:
        plt.figure(figsize=(6, 4))
        sns.histplot(df["Age"], kde=True)
        plt.title("Distribuição de Idade / Age distribution")
        plt.xlabel("Age")
        plt.savefig(os.path.join(figs_dir, "age_distribution.png"), bbox_inches="tight")
        plt.close()
    # salvar métricas em markdown
    md_path = os.path.join(out_dir, "metrics.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Métricas / Metrics\n\n")
        for k, v in metrics.items():
            f.write(f"- **{k}**: {v}\n")
