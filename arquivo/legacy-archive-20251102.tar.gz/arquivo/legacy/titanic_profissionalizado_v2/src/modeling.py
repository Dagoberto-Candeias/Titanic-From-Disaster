"""Modelagem: treino, validação e métricas (PT/EN)"""

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score, classification_report
from .utils import save_pickle


def train_and_evaluate(X, y, seed=42):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=seed, stratify=y
    )
    model = RandomForestClassifier(n_estimators=200, random_state=seed)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    probs = (
        model.predict_proba(X_test)[:, 1] if hasattr(model, "predict_proba") else None
    )
    metrics = {
        "accuracy": float(accuracy_score(y_test, preds)),
        "roc_auc": float(roc_auc_score(y_test, probs)) if probs is not None else None,
        "report": classification_report(y_test, preds, output_dict=True),
    }
    save_pickle(model, "reports/model.joblib")
    return model, metrics
