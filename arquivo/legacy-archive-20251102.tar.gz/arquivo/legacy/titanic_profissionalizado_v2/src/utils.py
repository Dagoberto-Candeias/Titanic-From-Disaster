"""Utils helpers (carregamento, salvamento, pequenas funções) -- PT/EN"""

import os
import pandas as pd
import joblib


def save_pickle(obj, path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    joblib.dump(obj, path)


def load_csv(path: str) -> pd.DataFrame:
    return pd.read_csv(path)
