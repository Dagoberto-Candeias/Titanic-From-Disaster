from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from .utils import save_pickle


def train_and_evaluate(X, y):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = RandomForestClassifier(n_estimators=200)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    metrics = {"accuracy": accuracy_score(y_test, preds)}
    save_pickle(model, "reports/model.joblib")
    return model, metrics
