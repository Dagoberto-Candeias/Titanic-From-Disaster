from .utils import load_csv


def load_and_preprocess(path):
    df = load_csv(path)
    df["Age"] = df["Age"].fillna(df["Age"].median())
    df["Embarked"] = df["Embarked"].fillna("S")
    return df
