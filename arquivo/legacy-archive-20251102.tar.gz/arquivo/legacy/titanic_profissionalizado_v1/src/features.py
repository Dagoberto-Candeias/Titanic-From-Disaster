def build_features(df):
    X = df[["Pclass", "Sex", "Age", "Fare"]].copy()
    X["Sex"] = X["Sex"].map({"male": 0, "female": 1})
    X = X.fillna(X.median(numeric_only=True))
    y = df["Survived"] if "Survived" in df.columns else None
    return X, y
