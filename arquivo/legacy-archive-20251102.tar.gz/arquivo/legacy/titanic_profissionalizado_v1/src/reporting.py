import os
import matplotlib.pyplot as plt
import seaborn as sns


def render_report(df, X, y, model, metrics, out_dir="reports/"):
    os.makedirs(out_dir, exist_ok=True)
    if "Age" in df.columns:
        plt.figure()
        sns.histplot(df["Age"], kde=True)
        plt.title("Age Distribution")
        plt.savefig(os.path.join(out_dir, "age_distribution.png"))
    with open(os.path.join(out_dir, "metrics.md"), "w") as f:
        f.write(str(metrics))
