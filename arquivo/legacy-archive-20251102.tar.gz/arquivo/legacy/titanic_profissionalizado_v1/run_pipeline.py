from src.preprocessing import load_and_preprocess
from src.features import build_features
from src.modeling import train_and_evaluate
from src.reporting import render_report

if __name__ == "__main__":
    df = load_and_preprocess("data/raw/train.csv")
    X, y = build_features(df)
    model, metrics = train_and_evaluate(X, y)
    render_report(df, X, y, model, metrics)
