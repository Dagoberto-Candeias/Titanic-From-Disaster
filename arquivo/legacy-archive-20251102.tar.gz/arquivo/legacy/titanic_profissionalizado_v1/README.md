# Projeto Titanic — Versão Profissionalizada

Pipeline profissional bilíngue (PT/EN) com ETL, modelagem e relatórios.