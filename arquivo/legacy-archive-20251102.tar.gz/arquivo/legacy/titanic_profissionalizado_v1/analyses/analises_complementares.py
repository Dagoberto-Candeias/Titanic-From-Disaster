import shap


def explain_model(model, X):
    explainer = shap.TreeExplainer(model)
    return explainer.shap_values(X)
