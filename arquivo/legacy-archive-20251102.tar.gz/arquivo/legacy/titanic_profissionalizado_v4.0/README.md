Titanic Profissionalizado v4.0
=============================

Conteúdo:
- ELT579_118550_Titanic_DOCUMENTADO_ComRelatorio_FIXED.py  (script corrigido)
- scripts/prompt_corrigir_script.txt  (prompt de correção original)
- scripts/prompt_corrigir_script_improved.txt  (prompt melhorado e checklist)
- data/raw/train.csv, data/raw/test.csv (se presentes)
- output/ (relatórios, gráficos e summary.json - gerados se o pipeline foi executado)

Instruções rápidas:
1. Coloque seu train.csv em data/raw/ (já incluído se enviado).
2. Execute: python ELT579_118550_Titanic_DOCUMENTADO_ComRelatorio_FIXED.py --data data/raw/train.csv --out output
3. Após execução, verifique output/ para relatórios e graficos.
