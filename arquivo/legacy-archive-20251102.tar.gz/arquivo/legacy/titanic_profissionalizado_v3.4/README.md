# Titanic Profissionalizado v3.4

Pacote com formatação acadêmica - pronto para executar o pipeline.