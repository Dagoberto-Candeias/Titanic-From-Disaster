#!/usr/bin/env python3
"""Gera DOCX e PDF a partir do markdown usando pandoc se disponível. Inclui TOC numerado e capa textual."""
import shutil
import subprocess
from pathlib import Path


def main():
    md = Path("output/RELATORIO_FINAL_TITANIC_COMPLETO.md")
    if not md.exists():
        print("Markdown não encontrado. Execute o pipeline primeiro.")
        return
    if shutil.which("pandoc"):
        try:
            subprocess.check_call(
                [
                    "pandoc",
                    str(md),
                    "--toc",
                    "--number-sections",
                    "-o",
                    "output/RELATORIO_FINAL_TITANIC_COMPLETO.pdf",
                    "--pdf-engine=xelatex",
                ]
            )
            subprocess.check_call(
                [
                    "pandoc",
                    str(md),
                    "--toc",
                    "--number-sections",
                    "-o",
                    "output/RELATORIO_FINAL_TITANIC_COMPLETO.docx",
                ]
            )
            print("Arquivos gerados com pandoc (TOC numerado).")
            return
        except Exception as e:
            print("Erro pandoc:", e)
    # fallback basic conversion using python-docx/reportlab
    try:
        from docx import Document
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas

        text = md.read_text(encoding="utf-8").splitlines()
        doc = Document()
        for line in text:
            if line.startswith("# "):
                doc.add_heading(line.lstrip("# ").strip(), level=1)
            elif line.startswith("## "):
                doc.add_heading(line.lstrip("## ").strip(), level=2)
            elif line.startswith("### "):
                doc.add_heading(line.lstrip("### ").strip(), level=3)
            else:
                doc.add_paragraph(line)
        doc.save("output/RELATORIO_FINAL_TITANIC_COMPLETO.docx")
        # PDF simple
        c = canvas.Canvas("output/RELATORIO_FINAL_TITANIC_COMPLETO.pdf", pagesize=A4)
        width, height = A4
        y = height - 40
        for paragraph in text:
            if y < 60:
                c.showPage()
                y = height - 40
            c.drawString(40, y, paragraph[:120])
            y -= 14
        c.save()
        print("Conversão fallback concluída.")
    except Exception as e:
        print("Falha no fallback:", e)


if __name__ == "__main__":
    main()
