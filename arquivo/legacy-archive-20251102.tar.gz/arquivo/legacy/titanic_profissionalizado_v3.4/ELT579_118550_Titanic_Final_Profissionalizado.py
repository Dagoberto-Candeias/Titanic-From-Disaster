#!/usr/bin/env python3
"""ELT579_118550_Titanic_Final_Profissionalizado.py
Versão v3.4 - pipeline com geração de relatório formatado (capa textual, TOC numerado para pandoc).
"""
import os
import json
import argparse
from datetime import datetime


def run_pipeline(data="data/raw/train.csv", out="output"):
    import pandas as pd
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import (
        accuracy_score,
        precision_score,
        recall_score,
        f1_score,
        roc_auc_score,
        confusion_matrix,
    )
    import matplotlib.pyplot as plt
    import seaborn as sns
    import joblib

    sns.set_theme(style="whitegrid")
    os.makedirs(out, exist_ok=True)
    figs = os.path.join(out, "graficos")
    os.makedirs(figs, exist_ok=True)
    if not os.path.exists(data):
        print("Coloque o arquivo train.csv em", data)
        return
    df = pd.read_csv(data)
    df["_original_index"] = df.index
    # preprocessing
    if "Age" in df.columns:
        df["Age"] = df["Age"].fillna(df["Age"].median())
    if "Embarked" in df.columns:
        df["Embarked"] = df["Embarked"].fillna(
            df["Embarked"].mode().iloc[0] if not df["Embarked"].mode().empty else "S"
        )
    if "Fare" in df.columns:
        df["Fare"] = df["Fare"].fillna(df["Fare"].median())
    if "Name" in df.columns:
        df["Title"] = (
            df["Name"]
            .str.extract(r",\s*([^\.]+)\.")
            .replace({"Mlle": "Miss", "Ms": "Miss", "Mme": "Mrs"})
        )
    if "SibSp" in df.columns and "Parch" in df.columns:
        df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
        df["IsAlone"] = (df["FamilySize"] == 1).astype(int)
    if "Sex" in df.columns:
        df["Sex_code"] = df["Sex"].map({"male": 0, "female": 1}).astype(int)
    # EDA plots
    try:
        if "Survived" in df.columns:
            plt.figure()
            sns.countplot(data=df, x="Survived")
            plt.title("Distribuição de sobrevivência")
            plt.savefig(os.path.join(figs, "01_distribuicao_sobrevivencia.png"))
            plt.close()
        if "Pclass" in df.columns and "Survived" in df.columns:
            plt.figure()
            sns.countplot(data=df, x="Pclass", hue="Survived")
            plt.title("Sobrevivência por classe (Pclass)")
            plt.savefig(os.path.join(figs, "02_sobrevivencia_por_pclass.png"))
            plt.close()
        if "Sex" in df.columns and "Survived" in df.columns:
            plt.figure()
            sns.countplot(data=df, x="Sex", hue="Survived")
            plt.title("Sobrevivência por sexo (Sex)")
            plt.savefig(os.path.join(figs, "03_sobrevivencia_por_sexo.png"))
            plt.close()
        if "Age" in df.columns:
            plt.figure()
            sns.histplot(df["Age"].dropna(), kde=True)
            plt.title("Distribuição de idades")
            plt.savefig(os.path.join(figs, "04_distribuicao_idades.png"))
            plt.close()
        num = df.select_dtypes(include=["float64", "int64"])
        if not num.empty:
            plt.figure(figsize=(8, 6))
            sns.heatmap(num.corr(), annot=True, fmt=".2f", cmap="coolwarm")
            plt.title("Mapa de correlação (numeric)")
            plt.savefig(os.path.join(figs, "05_mapa_correlacao.png"))
            plt.close()
    except Exception as e:
        print("Erro EDA:", e)
    # Modeling
    metrics = {}
    if "Survived" in df.columns:
        feats = [
            c
            for c in ["Pclass", "Sex_code", "Age", "Fare", "FamilySize", "IsAlone"]
            if c in df.columns
        ]
        X = df[feats].fillna(df[feats].median())
        y = df["Survived"]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        clf = RandomForestClassifier(n_estimators=200, random_state=42)
        clf.fit(X_train, y_train)
        preds = clf.predict(X_test)
        probs = (
            clf.predict_proba(X_test)[:, 1] if hasattr(clf, "predict_proba") else None
        )
        metrics["accuracy"] = float(accuracy_score(y_test, preds))
        metrics["precision"] = float(precision_score(y_test, preds, zero_division=0))
        metrics["recall"] = float(recall_score(y_test, preds, zero_division=0))
        metrics["f1"] = float(f1_score(y_test, preds, zero_division=0))
        metrics["roc_auc"] = (
            float(roc_auc_score(y_test, probs)) if probs is not None else None
        )
        metrics["confusion_matrix"] = confusion_matrix(y_test, preds).tolist()
        try:
            fi = clf.feature_importances_.tolist()
            metrics["feature_importance"] = dict(zip(X.columns, fi))
            plt.figure()
            sns.barplot(
                x=list(metrics["feature_importance"].values()),
                y=list(metrics["feature_importance"].keys()),
            )
            plt.title("Importância das variáveis")
            plt.tight_layout()
            plt.savefig(os.path.join(figs, "06_feature_importance.png"))
            plt.close()
            import matplotlib.pyplot as plt
            import seaborn as sns

            cm = confusion_matrix(y_test, preds)
            plt.figure()
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
            plt.title("Matriz de confusão")
            plt.savefig(os.path.join(figs, "07_matriz_confusao.png"))
            plt.close()
        except Exception as e:
            print("Erro feature importance:", e)
    # save metrics and model
    try:
        import joblib

        joblib.dump(clf, os.path.join(out, "model.joblib"))
    except Exception:
        pass
    with open(os.path.join(out, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(
            {"generated_at": datetime.utcnow().isoformat(), "metrics": metrics},
            f,
            indent=2,
            ensure_ascii=False,
        )
    # write markdown report with TOC placeholder for pandoc
    md = os.path.join(out, "RELATORIO_FINAL_TITANIC_COMPLETO.md")
    header = """Universidade Federal de Viçosa (UFV)
Departamento de Engenharia Elétrica – ELT579 – Aprendizado de Máquina
Projeto: Titanic – Machine Learning from Disaster
Autor: Dagoberto Candeias de Moraes
Ano: 2025"""
    with open(md, "w", encoding="utf-8") as f:
        f.write(header + "\n\n")
        f.write(
            "[TOC]\n\n"
        )  # pandoc will replace this with a TOC if used with proper flags
        f.write("# RELATÓRIO FINAL — TITANIC (VERSÃO PROFISSIONALIZADA)\n\n")
        f.write("## 1. Resumo\n\nRelatório gerado automaticamente.\n\n")
        f.write("## 2. Introdução\n\nContextualização do problema.\n\n")
        f.write("## 3. Metodologia\n\nDescrição resumida.\n\n")
        f.write("### 3.1 Pré-processamento e engenharia de atributos\n\n")
        f.write("Descritivo das transformações aplicadas.\n\n")
        f.write("## 4. Análise Exploratória\n\n")
        for img in sorted(os.listdir(os.path.join(out, "graficos"))):
            f.write(f"![](graficos/{img})\n\n")
        f.write("## 5. Resultados e Discussão\n\n")
        for k, v in metrics.items():
            f.write(f"- **{k}**: {v}\n")
        f.write("\n## 6. Conclusões e Trabalhos Futuros\n\n")
        f.write("\n## Apêndice A – Diretrizes de Geração do Relatório\n\n")
        f.write("Apêndice conforme especificado.\n")
    print("Relatório Markdown gerado em", md)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/raw/train.csv")
    parser.add_argument("--out", default="output")
    args = parser.parse_args()
    run_pipeline(args.data, args.out)
