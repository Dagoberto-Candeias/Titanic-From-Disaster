# -*- coding: utf-8 -*-
"""
TITANIC: MACHINE LEARNING FROM DISASTER - VERSÃO FINAL GARANTIDA
Baseado no teste que funcionou perfeitamente

Autor: Dagoberto Candeias de Moraes
Disciplina: UFV - ELT 579
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import os
from datetime import datetime

# Suprimir warnings
warnings.filterwarnings("ignore")

# Configurações básicas
plt.style.use("seaborn-v0_8-whitegrid")
sns.set_palette("husl")

print("Bibliotecas carregadas com sucesso!")

# =============================================================================
# EXECUÇÃO GARANTIDA - BASEADA NO TESTE QUE FUNCIONOU
# =============================================================================


def main():
    """Função principal que GARANTE a geração de todos os arquivos."""
    print("=" * 80)
    print("TITANIC - ANALISE GARANTIDA")
    print("=" * 80)

    try:
        # 1. Criar diretórios necessários
        print("\nCRIANDO DIRETORIOS...")
        os.makedirs("output/graficos", exist_ok=True)
        os.makedirs("output/relatorios", exist_ok=True)
        print("   Diretorios criados")

        # 2. Carregar dados
        print("\nCARREGANDO DADOS...")
        train = pd.read_csv("train.csv")
        test = pd.read_csv("test.csv")
        print(f"   Dados carregados: Treino={train.shape}, Teste={test.shape}")

        # 3. Criar features básicas
        print("\nCRIANDO FEATURES...")
        for df in [train, test]:
            df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
            df["IsAlone"] = (df["FamilySize"] == 1).astype(int)
            df["Age"] = df["Age"].fillna(df["Age"].median())
            df["Fare"] = df["Fare"].fillna(df["Fare"].median())
            df["Sex"] = df["Sex"].map({"male": 0, "female": 1})

        print(f"   Features criadas: {train.shape[1]} colunas")

        # 4. Criar gráfico EDA
        print("\nGERANDO GRAFICO EDA...")
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Gráfico 1: Sobrevivência por sexo
        sobrevivencia_sexo = train.groupby("Sex")["Survived"].mean()
        sobrevivencia_sexo.plot(kind="bar", ax=axes[0, 0], color=["lightblue", "pink"])
        axes[0, 0].set_title("Taxa de Sobrevivencia por Sexo")
        axes[0, 0].set_ylabel("Taxa de Sobrevivencia")

        # Gráfico 2: Sobrevivência por classe
        sobrevivencia_classe = train.groupby("Pclass")["Survived"].mean()
        sobrevivencia_classe.plot(kind="bar", ax=axes[0, 1], color="lightgreen")
        axes[0, 1].set_title("Taxa de Sobrevivencia por Classe")
        axes[0, 1].set_ylabel("Taxa de Sobrevivencia")

        # Gráfico 3: Distribuição de idade
        survived = train[train["Survived"] == 1]["Age"].dropna()
        not_survived = train[train["Survived"] == 0]["Age"].dropna()

        axes[1, 0].hist(
            [not_survived, survived],
            bins=30,
            alpha=0.7,
            label=["Nao Sobreviveu", "Sobreviveu"],
            color=["red", "green"],
        )
        axes[1, 0].set_xlabel("Idade")
        axes[1, 0].set_ylabel("Numero de Passageiros")
        axes[1, 0].set_title("Distribuicao de Idade por Sobrevivencia")
        axes[1, 0].legend()

        # Gráfico 4: Sobrevivência por faixa etária
        bins = [0, 12, 18, 35, 60, 100]
        labels = ["Crianca", "Adolescente", "Jovem", "Adulto", "Idoso"]
        train["FaixaEtaria"] = pd.cut(train["Age"], bins=bins, labels=labels)
        sobrevivencia_faixa = train.groupby("FaixaEtaria")["Survived"].mean()
        sobrevivencia_faixa.plot(kind="bar", ax=axes[1, 1], color="orange")
        axes[1, 1].set_title("Taxa de Sobrevivencia por Faixa Etaria")
        axes[1, 1].set_ylabel("Taxa de Sobrevivencia")

        plt.tight_layout()
        plt.savefig("output/graficos/01_eda_completa.png", dpi=300, bbox_inches="tight")
        plt.close()
        print("   Grafico EDA salvo: output/graficos/01_eda_completa.png")

        # 5. Treinar modelos
        print("\nTREINANDO MODELOS...")
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
        from sklearn.linear_model import LogisticRegression
        from sklearn.svm import SVC
        from sklearn.model_selection import cross_val_score

        modelos = {
            "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
            "GradientBoosting": GradientBoostingClassifier(
                n_estimators=100, random_state=42
            ),
            "LogisticRegression": LogisticRegression(random_state=42, max_iter=1000),
            "SVM": SVC(random_state=42),
        }

        features = [
            "Pclass",
            "Sex",
            "Age",
            "SibSp",
            "Parch",
            "Fare",
            "FamilySize",
            "IsAlone",
        ]
        X_train = train[features]
        y_train = train["Survived"]

        resultados = {}
        for nome, modelo in modelos.items():
            try:
                scores = cross_val_score(
                    modelo, X_train, y_train, cv=5, scoring="accuracy"
                )
                resultados[nome] = {
                    "mean_score": scores.mean(),
                    "std_score": scores.std(),
                }
                print(f"   {nome}: {scores.mean():.4f} +- {scores.std():.4f}")
            except Exception as e:
                print(f"   {nome}: ERRO - {e}")
                continue

        # 6. Gerar gráfico de modelos
        print("\nGERANDO GRAFICO DE MODELOS...")
        if resultados:
            modelos_nomes = list(resultados.keys())
            scores = [resultados[modelo]["mean_score"] for modelo in modelos_nomes]
            stds = [resultados[modelo]["std_score"] for modelo in modelos_nomes]

            plt.figure(figsize=(10, 6))
            bars = plt.bar(
                range(len(modelos_nomes)), scores, yerr=stds, capsize=5, alpha=0.7
            )
            plt.xticks(
                range(len(modelos_nomes)), modelos_nomes, rotation=45, ha="right"
            )
            plt.ylabel("Acuracia (CV)")
            plt.title("Comparacao de Performance dos Modelos")
            plt.ylim(0.7, 0.9)

            for bar, score in zip(bars, scores):
                plt.text(
                    bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.005,
                    f"{score:.4f}",
                    ha="center",
                    va="bottom",
                    fontweight="bold",
                )

            plt.tight_layout()
            plt.savefig(
                "output/graficos/02_comparacao_modelos.png",
                dpi=300,
                bbox_inches="tight",
            )
            plt.close()
            print(
                "   Grafico de modelos salvo: output/graficos/02_comparacao_modelos.png"
            )

        # 7. Fazer predições
        print("\nGERANDO PREDICOES...")
        if resultados:
            melhor_modelo_nome = max(
                resultados.keys(), key=lambda x: resultados[x]["mean_score"]
            )
            modelo_final = modelos[melhor_modelo_nome]
            modelo_final.fit(X_train, y_train)
            X_test = test[features]
            predictions = modelo_final.predict(X_test)

            # Criar submission
            submission = pd.DataFrame(
                {"PassengerId": test["PassengerId"], "Survived": predictions}
            )
            submission.to_csv("output/submission_titanic_final.csv", index=False)
            print(f"   Predicoes salvas: {len(predictions)} registros")
            print("   Arquivo: output/submission_titanic_final.csv")
        # 8. Gerar relatório
        print("\nGERANDO RELATORIO...")
        num_modelos = len(resultados)
        if resultados:
            melhor_score = max([r["mean_score"] for r in resultados.values()])
            melhor_nome = max(
                resultados.keys(), key=lambda x: resultados[x]["mean_score"]
            )
        else:
            melhor_score = 0
            melhor_nome = "N/A"

        relatorio = f"""# Relatorio Final - Titanic: Machine Learning from Disaster

**Analise Completa e Documentada**

**Autor:** Dagoberto Candeias de Moraes
**Matricula:** 118550
**Disciplina:** UFV - ELT 579
**Data de Geracao:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## 1. Resumo Executivo

Analise implementada com **{num_modelos} algoritmos**.
Melhor acuracia alcancada: **{melhor_score:.4f}** com o modelo **{melhor_nome}**.

## 2. Modelos Testados

| Modelo | Acuracia (CV) |
|--------|---------------|
"""

        if resultados:
            for nome, perf in sorted(
                resultados.items(), key=lambda x: x[1]["mean_score"], reverse=True
            ):
                relatorio += f"| {nome} | {perf['mean_score']:.4f}|\n"
        else:
            relatorio += "| Nenhum modelo treinado | N/A |\n"

        relatorio += f"\n## 3. Conclusao\n\nAnalise executada com sucesso em {datetime.now().strftime('%d/%m/%Y')}."

        with open(
            "output/relatorios/RELATORIO_FINAL_TITANIC.md", "w", encoding="utf-8"
        ) as f:
            f.write(relatorio)

        print("   Relatorio salvo: output/relatorios/RELATORIO_FINAL_TITANIC.md")
        # 9. Verificação final
        print("\nVERIFICANDO ARQUIVOS GERADOS:")

        arquivos_esperados = [
            "output/submission_titanic_final.csv",
            "output/graficos/01_eda_completa.png",
            "output/graficos/02_comparacao_modelos.png",
            "output/relatorios/RELATORIO_FINAL_TITANIC.md",
        ]

        arquivos_encontrados = 0
        for arquivo in arquivos_esperados:
            if os.path.exists(arquivo):
                tamanho = os.path.getsize(arquivo)
                print(f"   OK: {arquivo} ({tamanho:,} bytes)")
                arquivos_encontrados += 1
            else:
                print(f"   FALTA: {arquivo}")

        print(
            f"\nRESUMO: {arquivos_encontrados}/{len(arquivos_esperados)} arquivos gerados"
        )

        if arquivos_encontrados >= 3:  # Pelo menos os 3 principais
            print("\nSUCESSO TOTAL!")
            print("=" * 80)
            print("Arquivos gerados na pasta 'output/'")
            print("Submeta 'output/submission_titanic_final.csv' no Kaggle!")
            return True
        else:
            print("\nAlguns arquivos podem nao ter sido gerados.")
            return False

    except Exception as e:
        print(f"\nERRO CRITICO: {e}")
        import traceback

        traceback.print_exc()
        return False


# =============================================================================
# EXECUÇÃO DIRETA
# =============================================================================

if __name__ == "__main__":
    sucesso = main()
