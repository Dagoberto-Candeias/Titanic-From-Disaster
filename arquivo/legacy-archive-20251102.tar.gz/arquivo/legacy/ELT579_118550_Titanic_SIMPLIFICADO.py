# -*- coding: utf-8 -*-
"""
TITANIC: MACHINE LEARNING FROM DISASTER - VERSÃO FUNCIONAL SIMPLIFICADA
Baseado na versão anterior que funcionava perfeitamente

Autor: Dagoberto Candeias de Moraes
Disciplina: UFV - ELT 579
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import os
from datetime import datetime

# Suprimir warnings
warnings.filterwarnings('ignore')

# Configurações básicas
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette("husl")
plt.rcParams['figure.figsize'] = [12, 8]

# =============================================================================
# IMPORTAÇÕES PRINCIPAIS
# =============================================================================

from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import (RandomForestClassifier, VotingClassifier,
                            GradientBoostingClassifier, ExtraTreesClassifier,
                            AdaBoostClassifier, BaggingClassifier)
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

# XGBoost e LightGBM
from xgboost import XGBClassifier
try:
    from lightgbm import LGBMClassifier
    LGBM_AVAILABLE = True
except ImportError:
    LGBM_AVAILABLE = False

print("✅ Bibliotecas carregadas com sucesso!")

# =============================================================================
# ANÁLISE EXPLORATÓRIA - SIMPLIFICADA
# =============================================================================

def analise_exploratoria_completa(train):
    """Análise exploratória funcional."""
    print("📊 EXECUTANDO ANÁLISE EXPLORATÓRIA")

    try:
        os.makedirs('output/graficos', exist_ok=True)

        plt.figure(figsize=(12, 8))

        # Gráfico 1: Sobrevivência por sexo
        plt.subplot(2, 2, 1)
        train.groupby(['Sex', 'Survived']).size().unstack().plot(kind='bar', stacked=True, ax=plt.gca())
        plt.title('Sobreviventes por Sexo')
        plt.legend(['Não Sobreviveu', 'Sobreviveu'])

        # Gráfico 2: Sobrevivência por classe
        plt.subplot(2, 2, 2)
        train.groupby(['Pclass', 'Survived']).size().unstack().plot(kind='bar', stacked=True, ax=plt.gca())
        plt.title('Sobreviventes por Classe')

        # Gráfico 3: Distribuição de idade
        plt.subplot(2, 2, 3)
        plt.hist([train[train['Survived'] == 0]['Age'].dropna(),
                 train[train['Survived'] == 1]['Age'].dropna()],
                bins=30, alpha=0.7, label=['Não Sobreviveu', 'Sobreviveu'])
        plt.title('Distribuição de Idade')
        plt.legend()

        # Gráfico 4: Taxa de sobrevivência por faixa etária
        plt.subplot(2, 2, 4)
        age_bins = [0, 12, 18, 35, 60, 100]
        age_labels = ['Criança', 'Adolescente', 'Jovem', 'Adulto', 'Idoso']
        train['FaixaEtaria'] = pd.cut(train['Age'], bins=age_bins, labels=age_labels)
        survival_rate = train.groupby('FaixaEtaria')['Survived'].mean()
        survival_rate.plot(kind='bar', ax=plt.gca())
        plt.title('Taxa de Sobrevivência por Faixa Etária')

        plt.tight_layout()
        plt.savefig('output/graficos/01_eda_completa.png', dpi=300, bbox_inches='tight')
        plt.close()

        print("   ✅ Gráfico EDA salvo")

    except Exception as e:
        print(f"   ❌ Erro no EDA: {e}")

# =============================================================================
# FEATURE ENGINEERING - SIMPLIFICADO E FUNCIONAL
# =============================================================================

def criar_features_completas(train, test):
    """Cria todas as features necessárias."""
    print("🛠️ CRIANDO FEATURES...")

    for df in [train, test]:
        # Título (precisa da coluna 'Name')
        df['Title'] = df['Name'].str.extract(' ([A-Za-z]+)\\.', expand=False)
        df['Title'] = df['Title'].replace(['Lady', 'Countess','Capt', 'Col','Don', 'Dr', 'Major', 'Rev', 'Sir', 'Jonkheer', 'Dona'], 'Rare')
        df['Title'] = df['Title'].replace('Mlle', 'Miss')
        df['Title'] = df['Title'].replace('Ms', 'Miss')
        df['Title'] = df['Title'].replace('Mme', 'Mrs')

        # Família
        df['FamilySize'] = df['SibSp'] + df['Parch'] + 1
        df['IsAlone'] = (df['FamilySize'] == 1).astype(int)

        # Grupos de idade
        df['AgeGroup'] = pd.cut(df['Age'].fillna(df['Age'].median()), bins=[0, 12, 18, 35, 60, 100], labels=['Child', 'Teen', 'Young', 'Adult', 'Senior'])
        df['AgeGroup'] = df['AgeGroup'].astype(str)

        # Estatísticas por grupos
        df['FarePerClass'] = df.groupby('Pclass')['Fare'].transform(lambda x: x / x.mean())
        df['AgePerClass'] = df.groupby('Pclass')['Age'].transform(lambda x: x / x.mean())

        # Interações
        df['Age_Class'] = df['Age'] * df['Pclass']
        df['Fare_Pclass'] = df['Fare'] * df['Pclass']
        df['Sex_Pclass'] = df['Sex'].map({'male': 0, 'female': 1}) * df['Pclass']

        # Polinomiais
        df['Age_squared'] = df['Age'] ** 2
        df['Fare_squared'] = df['Fare'] ** 2

        # Social
        title_status = {
            'Mr': 1, 'Mrs': 3, 'Miss': 2, 'Master': 2,
            'Rare': 3, 'Dr': 4, 'Rev': 2, 'Col': 4,
            'Major': 4, 'Capt': 3, 'Sir': 4
        }
        df['SocialStatus'] = df['Title'].map(title_status)

        # Riqueza relativa (fare por classe)
        df['WealthClass'] = df.groupby('Pclass')['Fare'].transform(lambda x: pd.qcut(x, 3, labels=[1, 2, 3]))
        df['WealthClass'] = df['WealthClass'].fillna(2).astype(int)

    return train, test

def aplicar_target_encoding(train, test):
    """Aplica target encoding."""
    print("🎯 APLICANDO TARGET ENCODING...")

    # Recarregar treino completo para target encoding
    train_full = pd.read_csv('train.csv')

    target_vars = ['Title', 'Embarked', 'AgeGroup']
    for var in target_vars:
        if var in train.columns:
            target_means = train_full.groupby(var)['Survived'].mean()
            for df in [train, test]:
                df[f'{var}_TE'] = df[var].map(target_means).fillna(0.5)

    return train, test

# =============================================================================
# MODELAGEM - SIMPLIFICADA E FUNCIONAL
# =============================================================================

def criar_e_treinar_modelos(X_train, y_train, X_test=None):
    """Cria e treina todos os modelos."""
    print("🤖 CRIANDO E TREINANDO MODELOS...")

    modelos = {
        'RandomForest': RandomForestClassifier(n_estimators=100, random_state=42),
        'XGBoost': XGBClassifier(n_estimators=100, random_state=42, verbosity=0),
        'GradientBoosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
        'ExtraTrees': ExtraTreesClassifier(n_estimators=100, random_state=42),
        'LogisticRegression': LogisticRegression(random_state=42, max_iter=1000),
        'SVC': SVC(probability=True, random_state=42),
        'KNN': KNeighborsClassifier(),
        'DecisionTree': DecisionTreeClassifier(random_state=42),
        'GaussianNB': GaussianNB(),
        'LDA': LinearDiscriminantAnalysis(),
        'AdaBoost': AdaBoostClassifier(n_estimators=100, random_state=42),
        'Bagging': BaggingClassifier(n_estimators=100, random_state=42)
    }

    # Adicionar LightGBM se disponível
    if LGBM_AVAILABLE:
        modelos['LightGBM'] = LGBMClassifier(n_estimators=100, random_state=42, verbosity=-1)

    # Treinar e avaliar
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    model_performance = {}

    for nome, modelo in modelos.items():
        try:
            scores = cross_val_score(modelo, X_train, y_train, cv=cv, scoring='accuracy')
            model_performance[nome] = {
                'mean_score': scores.mean(),
                'std_score': scores.std(),
                'model': modelo
            }
            print(f"   ✅ {nome}: {scores.mean():.4f} ± {scores.std():.4f}")

            if X_test is not None:
                modelo.fit(X_train, y_train)

        except Exception as e:
            print(f"   ❌ {nome}: {e}")
            continue

    return modelos, model_performance

# =============================================================================
# GERAÇÃO DE ARQUIVOS - SIMPLIFICADA
# =============================================================================

def gerar_graficos_modelos(model_performance):
    """Gera gráficos de comparação de modelos."""
    try:
        os.makedirs('output/graficos', exist_ok=True)

        modelos = list(model_performance.keys())
        scores = [model_performance[modelo]['mean_score'] for modelo in modelos]
        stds = [model_performance[modelo]['std_score'] for modelo in modelos]

        plt.figure(figsize=(12, 6))
        bars = plt.bar(range(len(modelos)), scores, yerr=stds, capsize=5, alpha=0.7)
        plt.xticks(range(len(modelos)), modelos, rotation=45, ha='right')
        plt.ylabel('Acurácia (CV)')
        plt.title('Comparação de Performance dos Modelos')
        plt.ylim(0.7, 0.9)

        for bar, score in zip(bars, scores):
            plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.005,
                    f'{score".4f"}', ha='center', va='bottom', fontweight='bold')

        plt.tight_layout()
        plt.savefig('output/graficos/02_comparacao_modelos.png', dpi=300, bbox_inches='tight')
        plt.close()

        print("   ✅ Gráfico de modelos salvo")

    except Exception as e:
        print(f"   ❌ Erro nos gráficos: {e}")

def gerar_relatorio_completo(feature_names, model_performance):
    """Gera relatório completo."""
    try:
        os.makedirs('output/relatorios', exist_ok=True)

        # Estatísticas básicas
        atual_stats = {
            'features': len(feature_names),
            'modelos': len(model_performance),
            'melhor_acuracia': max([p['mean_score'] for p in model_performance.values()]) if model_performance else 0,
            'melhor_modelo': max(model_performance.keys(), key=lambda x: model_performance[x]['mean_score']) if model_performance else 'N/A'
        }

        # Relatório Markdown
        md_content = f"""# 🚢 Relatório Final - Titanic: Machine Learning from Disaster

**Análise Completa e Documentada**

**Autor:** Dagoberto Candeias de Moraes
**Matrícula:** 118550
**Disciplina:** UFV - ELT 579
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## 1. Resumo Executivo

Solução avançada implementada com **{atual_stats['features']} features** e **{atual_stats['modelos']} algoritmos**.
Melhor acurácia alcançada: **{atual_stats['melhor_acuracia']:.4f}** com o modelo **{atual_stats['melhor_modelo']}**.

## 2. Features Implementadas

**Categorias de Features:**
1. **Básicas:** Title, FamilySize, IsAlone, AgeGroup
2. **Estatísticas:** FarePerClass, AgePerClass
3. **Interação:** Age_Class, Fare_Pclass, Sex_Pclass
4. **Polinomiais:** Age², Fare²
5. **Sociais:** SocialStatus, WealthClass
6. **Target Encoding:** Title_TE, Embarked_TE, AgeGroup_TE

## 3. Modelos Testados

| Modelo | Acurácia (CV) |
|--------|---------------|
"""

        # Adicionar resultados dos modelos
        if model_performance:
            for nome, perf in sorted(model_performance.items(), key=lambda x: x[1]['mean_score'], reverse=True):
                md_content += f"| {nome} | {perf['mean_score']:.4".4f"|\n"

        md_content += f"\n## 4. Conclusão\n\nAnálise executada com sucesso em {datetime.now().strftime('%d/%m/%Y')}."

        # Salvar Markdown
        with open('output/relatorios/RELATORIO_FINAL_TITANIC.md', 'w', encoding='utf-8') as f:
            f.write(md_content)

        print("   ✅ Relatório Markdown salvo")

    except Exception as e:
        print(f"   ❌ Erro no relatório: {e}")

# =============================================================================
# EXECUÇÃO PRINCIPAL - SIMPLIFICADA E FUNCIONAL
# =============================================================================

def main():
    """Função principal simplificada baseada na versão funcional."""
    print("=" * 80)
    print("🚀 TITANIC - ANÁLISE COMPLETA SIMPLIFICADA")
    print("=" * 80)

    try:
        # 1. Carregar dados
        print("\n📥 CARREGANDO DADOS...")
        train = pd.read_csv('train.csv')
        test = pd.read_csv('test.csv')
        print(f"   ✅ Treino: {train.shape}, Teste: {test.shape}")

        # 2. Análise exploratória
        print("\n📊 ANÁLISE EXPLORATÓRIA...")
        analise_exploratoria_completa(train)

        # 3. Preparar dados (remover colunas desnecessárias)
        print("\n🔧 PREPARANDO DADOS...")
        colunas_para_remover = ['Name', 'Ticket', 'Cabin']
        train = train.drop(colunas_para_remover, axis=1, errors='ignore')
        test = test.drop(colunas_para_remover, axis=1, errors='ignore')

        # 4. Feature Engineering
        print("\n🛠️ FEATURE ENGINEERING...")
        train, test = criar_features_completas(train, test)
        train, test = aplicar_target_encoding(train, test)

        # 5. Pré-processamento
        print("\n📝 PRÉ-PROCESSAMENTO...")
        X_train = train.drop(['Survived', 'PassengerId'], axis=1, errors='ignore')
        y_train = train['Survived']
        X_test = test.drop(['PassengerId'], axis=1, errors='ignore')

        # Imputação
        num_imputer = SimpleImputer(strategy='median')
        cat_imputer = SimpleImputer(strategy='most_frequent')

        # Separar features
        categorical_features = ['Sex', 'Embarked', 'Title', 'AgeGroup']
        numerical_features = [col for col in X_train.columns if col not in categorical_features]

        # Aplicar imputação
        X_train[numerical_features] = num_imputer.fit_transform(X_train[numerical_features])
        X_test[numerical_features] = num_imputer.transform(X_test[numerical_features])
        X_train[categorical_features] = cat_imputer.fit_transform(X_train[categorical_features])
        X_test[categorical_features] = cat_imputer.transform(X_test[categorical_features])

        # Encoding
        preprocessor = ColumnTransformer(
            transformers=[
                ('num', StandardScaler(), numerical_features),
                ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
            ])

        X_train_processed = preprocessor.fit_transform(X_train)
        X_test_processed = preprocessor.transform(X_test)

        # Nomes das features
        feature_names = numerical_features + list(preprocessor.named_transformers_['cat'].get_feature_names_out(categorical_features))
        X_train_processed = pd.DataFrame(X_train_processed, columns=feature_names, index=X_train.index)
        X_test_processed = pd.DataFrame(X_test_processed, columns=feature_names, index=X_test.index)

        print(f"   ✅ Dados pré-processados: {X_train_processed.shape}")

        # 6. Modelagem
        print("\n🤖 MODELAGEM...")
        modelos, model_performance = criar_e_treinar_modelos(X_train_processed, y_train, X_test_processed)

        # 7. Gráficos
        print("\n📊 GERANDO GRÁFICOS...")
        gerar_graficos_modelos(model_performance)

        # 8. Predições finais
        print("\n🎯 GERANDO PREDIÇÕES...")
        melhor_nome = max(model_performance.keys(), key=lambda x: model_performance[x]['mean_score'])
        modelo_final = model_performance[melhor_nome]['model']
        modelo_final.fit(X_train_processed, y_train)
        predictions = modelo_final.predict(X_test_processed)

        # Salvar submission
        submission = pd.DataFrame({
            'PassengerId': pd.read_csv('test.csv')['PassengerId'],
            'Survived': predictions
        })
        submission.to_csv('output/submission_titanic_final.csv', index=False)
        print(f"   ✅ Predições salvas: {len(predictions)} registros")

        # 9. Relatório final
        print("\n📝 GERANDO RELATÓRIO...")
        gerar_relatorio_completo(feature_names, model_performance)

        # 10. Verificar arquivos gerados
        print("\n📁 VERIFICANDO ARQUIVOS GERADOS:")
        arquivos_esperados = [
            'output/submission_titanic_final.csv',
            'output/graficos/01_eda_completa.png',
            'output/graficos/02_comparacao_modelos.png',
            'output/relatorios/RELATORIO_FINAL_TITANIC.md'
        ]

        arquivos_encontrados = 0
        for arquivo in arquivos_esperados:
            if os.path.exists(arquivo):
                tamanho = os.path.getsize(arquivo)
                print(f"   ✅ {arquivo}: {tamanho:,}","ytes")
                arquivos_encontrados += 1
            else:
                print(f"   ❌ {arquivo}: NÃO ENCONTRADO")

        print(f"\n📊 RESUMO: {arquivos_encontrados}/{len(arquivos_esperados)} arquivos gerados")

        print("\n🎉 ANÁLISE COMPLETA FINALIZADA!")
        return predictions

    except Exception as e:
        print(f"\n❌ ERRO CRÍTICO: {e}")
        import traceback
        traceback.print_exc()
        return None

# =============================================================================
# EXECUÇÃO
# =============================================================================

if __name__ == "__main__":
    predictions = main()

    if predictions is not None:
        print("\n" + "="*80)
        print("✅ SUCESSO TOTAL!")
        print("="*80)
        print("📊 Arquivos gerados na pasta 'output/'")
        print("🎯 Submeta 'output/submission_titanic_final.csv' no Kaggle!")
    else:
        print("\n❌ EXECUÇÃO FALHOU")
