\"\"\"ELT579_118550_Titanic_Final_Comparativo.py
Script wrapper que tenta executar o script principal do projeto (rodando run_pipeline) e então gerar
o relatório final (Markdown + DOCX).

Instruções:
- Coloque este arquivo no mesmo diretório do seu script principal (ELT579  118550  -Titanic - Final Avancado - Otimizado e tuuning - full consolidado.py)
- Execute: python ELT579_118550_Titanic_Final_Comparativo.py
- O wrapper tentará executar o script principal via runpy.run_path e, se encontrar a função run_pipeline,
  irá chamá-la e gerar os relatórios automaticamente.
\"\"\"

import runpy, os, sys, textwrap
from pathlib import Path

SCRIPT_NAME = 'ELT579  118550  -Titanic - Final Avancado - Otimizado e tuuning - full consolidado.py'
script_path = Path(SCRIPT_NAME)
if not script_path.exists():
    print('Aviso: não encontrei o script principal no diretório atual:', SCRIPT_NAME)
    print('Coloque o script principal no mesmo diretório e execute novamente.')
    sys.exit(1)

# Executa o script principal num namespace isolado
ns = runpy.run_path(str(script_path))

# Se existir run_pipeline no namespace, chama e captura o retorno
if 'run_pipeline' in ns:
    try:
        print('Executando run_pipeline definido no script principal...')
        out = ns['run_pipeline'](save_folder='output')
        # Tenta importar e usar generate_final_reports do próprio script se existir
        if 'generate_final_reports' in ns:
            ns['generate_final_reports'](results_cv=out.get('results_cv'), train_metrics=out.get('train_metrics'), save_folder='output')
        else:
            # fallback: avisa que os relatórios devem ser gerados manualmente
            print('Função generate_final_reports não encontrada no script principal.')
            print('Por favor, execute o gerador de relatórios manualmente com os resultados retornados.')
    except Exception as e:
        print('Erro ao executar run_pipeline:', e)
else:
    print('Função run_pipeline não encontrada no script principal.')
    print('Você pode abrir o script principal e rodá-lo diretamente.')
