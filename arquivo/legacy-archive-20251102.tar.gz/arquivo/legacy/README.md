arquivo/legacy/ — Arquivo de versões antigas

O que é

Esta pasta contém cópias legadas e versões anteriores dos scripts, notebooks e recursos do projeto Titanic que foram movidos para reduzir ruído na raiz do repositório. As movimentações foram feitas usando `git mv` para preservar o histórico de commits.

Por que foram arquivados

- Evitar duplicação e confusão entre múltiplas versões do pipeline.
- Manter o histórico (audit trail) enquanto deixamos `main` limpa e com a versão atualizada.

Como restaurar arquivos/versões (exemplos)

1) Restaurar um arquivo ou pasta movida para `arquivo/legacy/` de volta à raiz do repositório:

```bash
# mover de volta (ajuste os caminhos conforme necessário)
git mv "arquivo/legacy/titanic_profissionalizado_v4.0/ELT579_118550_Titanic_DOCUMENTADO_ComRelatorio_FIXED.py" "arquivo/titanic_profissionalizado_v4.0/ELT579_118550_Titanic_DOCUMENTADO_ComRelatorio_FIXED.py"
# commit e push
git commit -m "chore(restore): mover arquivo de legacy de volta à localização original"
git push origin main
```

2) Recuperar apenas o conteúdo histórico (sem mover):

```bash
# exibir histórico do arquivo movido (history preservado)
git log --follow -- "arquivo/legacy/titanic_profissionalizado_v4.0/ELT579_118550_Titanic_DOCUMENTADO_ComRelatorio_FIXED.py"

# extrair uma versão antiga específica para um novo arquivo
git show <commit-hash>:"arquivo/legacy/.../nome_do_arquivo.py" > restored_version.py
```

Notas

- As operações de restauração criam novos commits; revise as mudanças antes de push.
- Se preferir, podemos compactar `arquivo/legacy/` em um release/tag e removê-lo do repositório principal — me diga se quer que eu faça isso.

Contato

Peça para eu restaurar arquivos específicos ou gerar um manifest com a lista completa dos itens movidos.
