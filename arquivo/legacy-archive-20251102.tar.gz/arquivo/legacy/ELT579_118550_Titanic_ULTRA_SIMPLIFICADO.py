# -*- coding: utf-8 -*-
"""
TITANIC: MACHINE LEARNING FROM DISASTER - VERSÃO ULTRA-SIMPLIFICADA
Garantia de geração de todos os arquivos necessários

Autor: Dagoberto Candeias de Moraes
Disciplina: UFV - ELT 579
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import os
from datetime import datetime

# Suprimir warnings
warnings.filterwarnings("ignore")

# Configurações básicas
plt.style.use("seaborn-v0_8-whitegrid")
sns.set_palette("husl")

print("✅ Bibliotecas carregadas com sucesso!")

# =============================================================================
# FUNÇÕES PRINCIPAIS - SIMPLIFICADAS AO MÁXIMO
# =============================================================================


def analise_exploratoria_basica(train):
    """Análise exploratória básica que sempre funciona."""
    print("📊 EXECUTANDO ANÁLISE EXPLORATÓRIA...")

    try:
        os.makedirs("output/graficos", exist_ok=True)

        # Criar figura com subplots
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # 1. Sobrevivência por sexo
        sobrevivencia_sexo = train.groupby("Sex")["Survived"].mean()
        sobrevivencia_sexo.plot(kind="bar", ax=axes[0, 0], color=["lightblue", "pink"])
        axes[0, 0].set_title("Taxa de Sobrevivência por Sexo")
        axes[0, 0].set_ylabel("Taxa de Sobrevivência")

        # 2. Sobrevivência por classe
        sobrevivencia_classe = train.groupby("Pclass")["Survived"].mean()
        sobrevivencia_classe.plot(kind="bar", ax=axes[0, 1], color="lightgreen")
        axes[0, 1].set_title("Taxa de Sobrevivência por Classe")
        axes[0, 1].set_ylabel("Taxa de Sobrevivência")

        # 3. Distribuição de idade por sobrevivência
        survived = train[train["Survived"] == 1]["Age"].dropna()
        not_survived = train[train["Survived"] == 0]["Age"].dropna()

        axes[1, 0].hist(
            [not_survived, survived],
            bins=30,
            alpha=0.7,
            label=["Não Sobreviveu", "Sobreviveu"],
            color=["red", "green"],
        )
        axes[1, 0].set_xlabel("Idade")
        axes[1, 0].set_ylabel("Número de Passageiros")
        axes[1, 0].set_title("Distribuição de Idade por Sobrevivência")
        axes[1, 0].legend()

        # 4. Sobrevivência por faixa etária
        bins = [0, 12, 18, 35, 60, 100]
        labels = ["Criança", "Adolescente", "Jovem", "Adulto", "Idoso"]
        train["FaixaEtaria"] = pd.cut(train["Age"], bins=bins, labels=labels)
        sobrevivencia_faixa = train.groupby("FaixaEtaria")["Survived"].mean()
        sobrevivencia_faixa.plot(kind="bar", ax=axes[1, 1], color="orange")
        axes[1, 1].set_title("Taxa de Sobrevivência por Faixa Etária")
        axes[1, 1].set_ylabel("Taxa de Sobrevivência")

        plt.tight_layout()
        plt.savefig("output/graficos/01_eda_completa.png", dpi=300, bbox_inches="tight")
        plt.close()

        print("   ✅ Gráfico EDA salvo: output/graficos/01_eda_completa.png")
        return True

    except Exception as e:
        print(f"   ❌ Erro no EDA: {e}")
        return False


def criar_features_essenciais(train, test):
    """Cria apenas as features essenciais que sempre funcionam."""
    print("🛠️ CRIANDO FEATURES ESSENCIAIS...")

    try:
        for df in [train, test]:
            # Features básicas que sempre funcionam
            df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
            df["IsAlone"] = (df["FamilySize"] == 1).astype(int)

            # Tratamento de idade
            df["Age"] = df["Age"].fillna(df["Age"].median())

            # Tratamento de tarifa
            df["Fare"] = df["Fare"].fillna(df["Fare"].median())

            # Conversão de sexo
            df["Sex"] = df["Sex"].map({"male": 0, "female": 1})

            # Tratamento de cabine
            df["HasCabin"] = (~df["Cabin"].isnull()).astype(int)

        print(f"   ✅ Features criadas: {train.shape[1]} colunas")
        return train, test

    except Exception as e:
        print(f"   ❌ Erro no feature engineering: {e}")
        return train, test


def treinar_modelos_basicos(X_train, y_train):
    """Treina modelos básicos que sempre funcionam."""
    print("🤖 TREINANDO MODELOS BÁSICOS...")

    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.model_selection import cross_val_score

    modelos = {
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
        "GradientBoosting": GradientBoostingClassifier(
            n_estimators=100, random_state=42
        ),
        "LogisticRegression": LogisticRegression(random_state=42, max_iter=1000),
        "SVM": SVC(random_state=42),
    }

    resultados = {}

    for nome, modelo in modelos.items():
        try:
            print(f"   🧪 Treinando {nome}...")
            scores = cross_val_score(modelo, X_train, y_train, cv=5, scoring="accuracy")
            resultados[nome] = {
                "mean_score": scores.mean(),
                "std_score": scores.std(),
                "model": modelo,
            }
            print(f"   ✅ {nome}: {scores.mean():.4f} ± {scores.std():.4f}")

        except Exception as e:
            print(f"   ❌ {nome}: {e}")
            continue

    return resultados


def gerar_grafico_modelos(resultados):
    """Gera gráfico de comparação de modelos."""
    print("📊 GERANDO GRÁFICO DE MODELOS...")

    try:
        os.makedirs("output/graficos", exist_ok=True)

        if not resultados:
            print("   ⚠️ Nenhum resultado para gráfico")
            return

        modelos = list(resultados.keys())
        scores = [resultados[modelo]["mean_score"] for modelo in modelos]
        stds = [resultados[modelo]["std_score"] for modelo in modelos]

        plt.figure(figsize=(10, 6))
        bars = plt.bar(range(len(modelos)), scores, yerr=stds, capsize=5, alpha=0.7)
        plt.xticks(range(len(modelos)), modelos, rotation=45, ha="right")
        plt.ylabel("Acurácia (CV)")
        plt.title("Comparação de Performance dos Modelos")
        plt.ylim(0.7, 0.9)

        for bar, score in zip(bars, scores):
            plt.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{score:.4f}",
                ha="center",
                va="bottom",
                fontweight="bold",
            )

        plt.tight_layout()
        plt.savefig(
            "output/graficos/02_comparacao_modelos.png", dpi=300, bbox_inches="tight"
        )
        plt.close()

        print("   ✅ Gráfico salvo: output/graficos/02_comparacao_modelos.png")

    except Exception as e:
        print(f"   ❌ Erro no gráfico: {e}")


def gerar_predicoes_e_submission(train, test, resultados):
    """Gera predições e arquivo de submission."""
    print("🎯 GERANDO PREDIÇÕES...")

    try:
        if not resultados:
            print("   ⚠️ Nenhum modelo treinado")
            return

        # Selecionar melhor modelo
        melhor_nome = max(resultados.keys(), key=lambda x: resultados[x]["mean_score"])
        modelo_final = resultados[melhor_nome]["model"]

        # Preparar dados para predição
        features = [
            "Pclass",
            "Sex",
            "Age",
            "SibSp",
            "Parch",
            "Fare",
            "FamilySize",
            "IsAlone",
            "HasCabin",
        ]
        X_train_final = train[features]
        X_test_final = test[features]

        # Treinar modelo final
        modelo_final.fit(X_train_final, train["Survived"])

        # Fazer predições
        predictions = modelo_final.predict(X_test_final)

        # Criar submission
        submission = pd.DataFrame(
            {"PassengerId": test["PassengerId"], "Survived": predictions}
        )

        submission.to_csv("output/submission_titanic_final.csv", index=False)

        print(f"   ✅ Predições salvas: {len(predictions)} registros")
        print("   📁 Arquivo: output/submission_titanic_final.csv")

    except Exception as e:
        print(f"   ❌ Erro nas predições: {e}")


def gerar_relatorio_basico(resultados):
    """Gera relatório básico."""
    print("📝 GERANDO RELATÓRIO...")

    try:
        os.makedirs("output/relatorios", exist_ok=True)

        # Estatísticas básicas
        num_modelos = len(resultados)
        if resultados:
            melhor_score = max([r["mean_score"] for r in resultados.values()])
            melhor_nome = max(
                resultados.keys(), key=lambda x: resultados[x]["mean_score"]
            )
        else:
            melhor_score = 0
            melhor_nome = "N/A"

        # Criar relatório
        relatorio = f"""# 🚢 Relatório Final - Titanic: Machine Learning from Disaster

**Análise Completa e Documentada**

**Autor:** Dagoberto Candeias de Moraes
**Matrícula:** 118550
**Disciplina:** UFV - ELT 579
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## 1. Resumo Executivo

Análise implementada com **{num_modelos} algoritmos**.
Melhor acurácia alcançada: **{melhor_score:.4f}** com o modelo **{melhor_nome}**.

## 2. Modelos Testados

| Modelo | Acurácia (CV) |
|--------|---------------|
"""

        if resultados:
            for nome, perf in sorted(
                resultados.items(), key=lambda x: x[1]["mean_score"], reverse=True
            ):
                relatorio += f"| {nome} | {perf['mean_score']:.4f}|\n"
        else:
            relatorio += "| Nenhum modelo treinado | N/A |\n"

        relatorio += f"\n## 3. Conclusão\n\nAnálise executada com sucesso em {datetime.now().strftime('%d/%m/%Y')}."

        # Salvar relatório
        with open(
            "output/relatorios/RELATORIO_FINAL_TITANIC.md", "w", encoding="utf-8"
        ) as f:
            f.write(relatorio)

        print("   ✅ Relatório salvo: output/relatorios/RELATORIO_FINAL_TITANIC.md")

    except Exception as e:
        print(f"   ❌ Erro no relatório: {e}")


def verificar_arquivos_gerados():
    """Verifica quais arquivos foram gerados."""
    print("\n📁 VERIFICANDO ARQUIVOS GERADOS:")

    arquivos_esperados = [
        "output/submission_titanic_final.csv",
        "output/graficos/01_eda_completa.png",
        "output/graficos/02_comparacao_modelos.png",
        "output/relatorios/RELATORIO_FINAL_TITANIC.md",
    ]

    arquivos_encontrados = 0
    for arquivo in arquivos_esperados:
        if os.path.exists(arquivo):
            tamanho = os.path.getsize(arquivo)
            print(f"   ✅ {arquivo}: {tamanho:,}", "ytes")
            arquivos_encontrados += 1
        else:
            print(f"   ❌ {arquivo}: NÃO ENCONTRADO")

    print(
        f"\n📊 RESUMO: {arquivos_encontrados}/{len(arquivos_esperados)} arquivos gerados"
    )
    return arquivos_encontrados == len(arquivos_esperados)


# =============================================================================
# EXECUÇÃO PRINCIPAL - GARANTIA DE SUCESSO
# =============================================================================


def main():
    """Função principal ultra-simplificada."""
    print("=" * 80)
    print("🚀 TITANIC - ANÁLISE ULTRA-SIMPLIFICADA")
    print("=" * 80)

    try:
        # 1. Carregar dados
        print("\n📥 CARREGANDO DADOS...")
        train = pd.read_csv("train.csv")
        test = pd.read_csv("test.csv")
        print(f"   ✅ Dados carregados: Treino={train.shape}, Teste={test.shape}")

        # 2. Análise exploratória
        if not analise_exploratoria_basica(train):
            print("   ⚠️ Continuando mesmo com erro no EDA...")

        # 3. Preparar dados
        print("\n🔧 PREPARANDO DADOS...")
        colunas_para_remover = ["Name", "Ticket", "Cabin"]
        train = train.drop(colunas_para_remover, axis=1, errors="ignore")
        test = test.drop(colunas_para_remover, axis=1, errors="ignore")
        print(f"   ✅ Dados preparados: Treino={train.shape}, Teste={test.shape}")

        # 4. Feature Engineering
        train, test = criar_features_essenciais(train, test)

        # 5. Modelagem
        print("\n🤖 MODELAGEM...")
        features = [
            "Pclass",
            "Sex",
            "Age",
            "SibSp",
            "Parch",
            "Fare",
            "FamilySize",
            "IsAlone",
            "HasCabin",
        ]
        X_train = train[features]
        y_train = train["Survived"]
        X_test = test[features]

        resultados = treinar_modelos_basicos(X_train, y_train)

        # 6. Gráficos
        gerar_grafico_modelos(resultados)

        # 7. Predições
        gerar_predicoes_e_submission(train, test, resultados)

        # 8. Relatório
        gerar_relatorio_basico(resultados)

        # 9. Verificação final
        sucesso = verificar_arquivos_gerados()

        if sucesso:
            print("\n🎉 ANÁLISE COMPLETA FINALIZADA COM SUCESSO!")
            print("📊 Todos os arquivos foram gerados corretamente!")
            return True
        else:
            print("\n⚠️ Alguns arquivos podem não ter sido gerados.")
            return False

    except Exception as e:
        print(f"\n❌ ERRO CRÍTICO: {e}")
        import traceback

        traceback.print_exc()
        return False


# =============================================================================
# EXECUÇÃO DIRETA
# =============================================================================

if __name__ == "__main__":
    sucesso = main()

    if sucesso:
        print("\n" + "=" * 80)
        print("✅ SUCESSO TOTAL!")
        print("=" * 80)
        print("📊 Arquivos gerados na pasta 'output/'")
        print("🎯 Submeta 'output/submission_titanic_final.csv' no Kaggle!")
    else:
        print("\n❌ ALGUNS PROBLEMAS OCORRERAM")
        print("   📋 Verifique os logs acima para identificar problemas")
