# Titanic — Versão Profissionalizada (v3)

Versão final (v3) — pacote completo pronto para rodar localmente e no Google Colab.
O dataset deve ser colocado manualmente em `data/raw/train.csv` antes de executar os scripts.

Principais comandos:
- Local: criar ambiente, instalar dependências e rodar `make report-pdf` ou `python run_pipeline.py --data data/raw/train.csv --out reports/`
- Colab: abrir `notebooks/Pipeline_Completo.ipynb` ou `notebooks/Run_Pipeline_Colab.ipynb` e seguir as células de setup (há instruções para upload manual do CSV).

Entrega: scripts em `src/`, notebooks em `notebooks/`, relatório em `reports/relatorio_final.md` (+ geração via Makefile/Pandoc quando disponível), figuras em `reports/figures/`, scripts auxiliares em `scripts/`.
