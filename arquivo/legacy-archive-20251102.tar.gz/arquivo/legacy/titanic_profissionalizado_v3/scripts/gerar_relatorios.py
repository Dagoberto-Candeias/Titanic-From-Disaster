"""scripts/gerar_relatorios.py
Gera relatorio_final.pdf ou .docx a partir de relatorio_final.md.
Usa pandoc se disponível; caso contrário, usa python-docx e reportlab (formatação básica).
"""

import argparse
import subprocess
import shutil
import sys
from pathlib import Path


def pandoc_available():
    return shutil.which("pandoc") is not None


def generate_with_pandoc(md_path, out_path):
    cmd = ["pandoc", str(md_path), "-o", str(out_path)]
    if out_path.suffix == ".pdf":
        cmd += ["--pdf-engine=xelatex"]
    subprocess.check_call(cmd)


def generate_with_python(md_path, out_path):
    from docx import Document
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    text = md_path.read_text(encoding="utf-8")
    if out_path.suffix == ".docx":
        doc = Document()
        for line in text.splitlines():
            if line.strip().startswith("# "):
                doc.add_heading(line.strip().lstrip("# ").strip(), level=1)
            elif line.strip().startswith("## "):
                doc.add_heading(line.strip().lstrip("## ").strip(), level=2)
            else:
                doc.add_paragraph(line)
        doc.save(out_path)
    elif out_path.suffix == ".pdf":
        c = canvas.Canvas(str(out_path), pagesize=A4)
        width, height = A4
        y = height - 40
        for paragraph in text.splitlines():
            if y < 60:
                c.showPage()
                y = height - 40
            txt = paragraph if len(paragraph) <= 120 else paragraph[:120]
            c.drawString(40, y, txt)
            y -= 14
        c.save()
    else:
        raise ValueError("Formato não suportado: " + str(out_path.suffix))


def main():
    parser = argparse.ArgumentParser(
        description="Gerar relatorio em docx/pdf a partir do markdown"
    )
    parser.add_argument("--to", choices=["pdf", "docx"], required=True)
    args = parser.parse_args()
    md_path = Path("reports/relatorio_final.md")
    if not md_path.exists():
        print(
            "relatorio_final.md não encontrado em reports/. Gere primeiro o markdown."
        )
        sys.exit(1)
    out_path = Path("reports/relatorio_final." + args.to)
    if pandoc_available():
        print("Usando pandoc para conversão...")
        generate_with_pandoc(md_path, out_path)
    else:
        print("Pandoc não disponível — usando conversão Python (formatação básica).")
        generate_with_python(md_path, out_path)
    print("Gerado:", out_path)


if __name__ == "__main__":
    main()
