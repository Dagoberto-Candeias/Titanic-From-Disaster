"""Análises complementares (PT/EN): explicabilidade, SHAP, comparação de modelos"""

try:
    import shap
except Exception:
    shap = None


def explain_model(model, X):
    if shap is None:
        raise RuntimeError(
            "SHAP não disponível. Instale shap para usar explain_model()."
        )
    expl = shap.TreeExplainer(model)
    return expl.shap_values(X)
