#!/usr/bin/env python3
import argparse
import shutil
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--to", choices=["pdf", "docx"], required=True)
    args = parser.parse_args()
    md = Path("output/RELATORIO_FINAL_TITANIC_COMPLETO.md")
    if not md.exists():
        print("Markdown não encontrado. Execute pipeline primeiro.")
        return
    if shutil.which("pandoc"):
        if args.to == "pdf":
            subprocess.check_call(
                [
                    "pandoc",
                    str(md),
                    "-o",
                    "output/RELATORIO_FINAL_TITANIC_COMPLETO.pdf",
                    "--pdf-engine=xelatex",
                ]
            )
        else:
            subprocess.check_call(
                [
                    "pandoc",
                    str(md),
                    "-o",
                    "output/RELATORIO_FINAL_TITANIC_COMPLETO.docx",
                ]
            )
        print("Gerado com pandoc.")
        return
    # fallback basic conversion
    try:
        from docx import Document
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas

        text = md.read_text(encoding="utf-8").splitlines()
        if args.to == "docx":
            doc = Document()
            for line in text:
                if line.startswith("# "):
                    doc.add_heading(line.lstrip("# ").strip(), level=1)
                elif line.startswith("## "):
                    doc.add_heading(line.lstrip("## ").strip(), level=2)
                else:
                    doc.add_paragraph(line)
            doc.save("output/RELATORIO_FINAL_TITANIC_COMPLETO.docx")
            print("DOCX gerado fallback.")
        else:
            c = canvas.Canvas("output/RELATORIO_FINAL_TITANIC_COMPLETO.pdf")
            width, height = A4
            y = height - 40
            for paragraph in text:
                if y < 60:
                    c.showPage()
                    y = height - 40
                c.drawString(40, y, paragraph[:120])
                y -= 14
            c.save()
            print("PDF gerado fallback.")
    except Exception as e:
        print("Erro no fallback:", e)


if __name__ == "__main__":
    main()
